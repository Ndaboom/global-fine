<?php

return [

    'home' => 'Accueil',
    'company' => 'Entreprise',
    'services' => 'Services',
    'projects' => 'Projets',
    'login' => 'Connexion'

];
