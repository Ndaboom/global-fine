@extends('base')

@section('styles')
<!-- REVOLUTION SLIDER CSS -->
<link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/settings.css">
<!-- REVOLUTION NAVIGATION STYLE -->
<link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/navigation.css">
@endsection

@section('content')
<div id="content" class="site-content">
    <div class="page-header flex-middle">
        <div class="container">
            <div class="inner flex-middle">
                <h1 class="page-title">{{ __('Sign In') }}</h1>
                <ul id="breadcrumbs" class="breadcrumbs none-style">
                    <li><a href="{{ route('home') }}">{{ __('Welcome') }}</a></li>
                    <li class="active">{{ __('Sign In') }}</li>
                </ul>
            </div>
        </div>
    </div>

    <section class="shop-cart">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="shop_checkout">
                        <livewire:auth.login />
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>
@endsection;