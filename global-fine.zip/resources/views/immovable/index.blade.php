@extends('base')

@section('styles')
@endsection

@section('content')
<livewire:immovable.index />
@endsection